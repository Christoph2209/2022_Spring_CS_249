package edu.soravic.Assign07;

import java.util.*;
import java.io.*;

public class TreasureMap extends CharImage {
    protected int curRowCnt;
    protected int curColCnt;

    public TreasureMap(int rowCnt, int colCnt, char fillChar) {
        super(rowCnt, colCnt, fillChar);
        curRowCnt = 0;
        curColCnt = 0;
    }

    public void clear() {
        curRowCnt = 0;
        curColCnt = 0;
        super.clear();
    }

    public int getCurRow() {
        return curRowCnt;
    }

    public int getCurCol() {
        return curColCnt;
    }

    public void setCurRow(int row) {
        curRowCnt = row;
    }

    public void setCurCol(int col) {
        curColCnt = col;
    }

    public void parseDirection(String dirLine) throws TreasureMapException {
        try {

        Scanner input = new Scanner(dirLine);

        String direction = input.next();
        int offset = input.nextInt();


        switch (direction) {
            case "north":   for (int i = 0; i < offset; i++){
                                setPos(curRowCnt,curColCnt, '.');
                                curRowCnt = curRowCnt - 1;
                            } 
                            setPos(curRowCnt, curColCnt, '.');
                            break; 
            case "south":   for (int i = 0; i < offset; i++){
                                setPos(curRowCnt,curColCnt, '.');
                                curRowCnt = curRowCnt + 1;
                            } 
                                setPos(curRowCnt, curColCnt, '.');
                            break;
            case "west":    for (int i = 0; i < offset; i++){
                                setPos(curRowCnt,curColCnt, '.');
                                curColCnt = curColCnt - 1;
                            } 
                                setPos(curRowCnt, curColCnt, '.');
                            break;
            case "east":    for (int i = 0; i < offset; i++){
                                setPos(curRowCnt,curColCnt, '.');
                                curColCnt = curColCnt + 1;
                            } 
                                setPos(curRowCnt, curColCnt, '.');
                            break;
            default:        input.close();
                            throw new TreasureMapException("BAD COMMAND!");
                            
        } 

        input.close();

        }
        catch(Exception e) {
            throw new TreasureMapException("YE CANNOT MOVE SO!", e);
        }
    }

    public void loadInstructions(String filename) throws TreasureMapException {
        try {
            Scanner read = new Scanner(new File(filename));
        
            while (read.hasNextLine()) {
                String line = read.nextLine();
                parseDirection(line);
            }
        setPos(getCurRow(), getCurCol(), 'X');
        read.close();
    }
        catch (Exception e) {
            clear();
            new TreasureMapException("YE CANNOT READ THIS MAP!", e);
        }
    }

    public void saveMap(String filename) throws TreasureMapException {
        try {
            PrintWriter writer = new PrintWriter(filename);
            writer.print(getMapString());

            writer.close();

        }
        catch (Exception e) {
           throw new TreasureMapException("SUCH TREASURE NEEDS BE SECRET!", e);
        }
    }
}
