package edu.soravic.Assign06;

public class Giant {
    protected String name;
    
    public Giant()
    {
        
    }
    public Giant(String name)
    {
        this.name = name;
    }

    public String getName()
    {
        return name;
    }
    public void setName(String name)
    {
        this.name = name;
    }
    public String toString()
    {
        return name;
    }
}
